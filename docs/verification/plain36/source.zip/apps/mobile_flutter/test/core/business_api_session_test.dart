import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:liuhetong_mobile/core/business_api_client.dart';
import 'package:liuhetong_mobile/core/business_auth_contracts.dart';
import 'package:liuhetong_mobile/core/session_store.dart';

final class MemoryStore implements SecureKeyValueStore {
  final values = <String, String>{};
  @override
  Future<void> delete(String key) async => values.remove(key);
  @override
  Future<String?> read(String key) async => values[key];
  @override
  Future<void> write(String key, String value) async => values[key] = value;
}

void main() {
  test('restore rotates and atomically replaces the stored token pair',
      () async {
    final storage = MemoryStore();
    final store = SecureSessionStore(storage);
    await store.saveSession(accessToken: 'old-a', refreshToken: 'old-r');
    final api = BusinessApiClient(
      baseUri: Uri.parse('https://business.example'),
      sessionStore: store,
      client: MockClient((request) async {
        expect(request.url.path, '/api/v1/auth/refresh');
        expect(jsonDecode(request.body)['refresh_token'], 'old-r');
        return http.Response(
          jsonEncode({'access_token': 'new-a', 'refresh_token': 'new-r'}),
          200,
          headers: {'content-type': 'application/json'},
        );
      }),
    );

    expect(await api.restoreSession(), BusinessSessionRestore.authenticated);
    expect((await store.session())?.accessToken, 'new-a');
    expect((await store.session())?.refreshToken, 'new-r');
  });

  test('network failure preserves tokens and reports offline', () async {
    final storage = MemoryStore();
    final store = SecureSessionStore(storage);
    await store.saveSession(accessToken: 'a', refreshToken: 'r');
    final api = BusinessApiClient(
      baseUri: Uri.parse('https://business.example'),
      sessionStore: store,
      client: MockClient((_) => throw http.ClientException('offline')),
    );

    expect(await api.restoreSession(), BusinessSessionRestore.offline);
    expect((await store.session())?.refreshToken, 'r');
  });

  test('authoritative refresh rejection clears the business session', () async {
    final storage = MemoryStore();
    final store = SecureSessionStore(storage);
    await store.saveSession(accessToken: 'a', refreshToken: 'revoked');
    final api = BusinessApiClient(
      baseUri: Uri.parse('https://business.example'),
      sessionStore: store,
      client: MockClient((_) async => http.Response(
            jsonEncode({
              'error': {'code': 'REFRESH_TOKEN_INVALID', 'message': 'invalid'}
            }),
            401,
          )),
    );

    expect(await api.restoreSession(), BusinessSessionRestore.invalid);
    expect(await store.session(), isNull);
  });

  test('logout revokes the refresh token before local cleanup', () async {
    final storage = MemoryStore();
    final store = SecureSessionStore(storage);
    await store.saveSession(accessToken: 'a', refreshToken: 'r');
    var revoked = false;
    final api = BusinessApiClient(
      baseUri: Uri.parse('https://business.example'),
      sessionStore: store,
      client: MockClient((request) async {
        revoked = jsonDecode(request.body)['refresh_token'] == 'r';
        return http.Response('', 204);
      }),
    );

    await api.logout();

    expect(revoked, isTrue);
    expect(await store.session(), isNull);
  });

  test('authenticated request refreshes once and replays with new access token',
      () async {
    final storage = MemoryStore();
    final store = SecureSessionStore(storage);
    await store.saveSession(accessToken: 'expired-a', refreshToken: 'valid-r');
    var balanceCalls = 0;
    final api = BusinessApiClient(
      baseUri: Uri.parse('https://business.example'),
      sessionStore: store,
      client: MockClient((request) async {
        if (request.url.path == '/api/v1/auth/refresh') {
          return http.Response(
            jsonEncode({'access_token': 'new-a', 'refresh_token': 'new-r'}),
            200,
          );
        }
        balanceCalls++;
        if (balanceCalls == 1) return http.Response('{}', 401);
        expect(request.headers['Authorization'], 'Bearer new-a');
        return http.Response(jsonEncode({'balance': '0.00'}), 200);
      }),
    );

    expect((await api.caibiBalance())['balance'], '0.00');
    expect(balanceCalls, 2);
  });

  test('concurrent 401s share a single refresh flight', () async {
    // 回归：并发请求同时 401 时只允许一次 refresh 网络调用。
    // 服务端对已消费 refresh token 的重放按 TOKEN_REUSE 撤销整个设备令牌族，
    // 无 single-flight 锁时首页聚合加载会互相触发撤族，把用户踢回登录页。
    final storage = MemoryStore();
    final store = SecureSessionStore(storage);
    await store.saveSession(accessToken: 'expired-a', refreshToken: 'valid-r');
    var refreshCalls = 0;
    final api = BusinessApiClient(
      baseUri: Uri.parse('https://business.example'),
      sessionStore: store,
      client: MockClient((request) async {
        if (request.url.path == '/api/v1/auth/refresh') {
          refreshCalls++;
          // 模拟网络往返，放大多个调用方同时进入刷新窗口的竞态。
          await Future<void>.delayed(const Duration(milliseconds: 20));
          return http.Response(
            jsonEncode({'access_token': 'new-a', 'refresh_token': 'new-r'}),
            200,
          );
        }
        if (request.headers['Authorization'] == 'Bearer expired-a') {
          return http.Response('{}', 401);
        }
        expect(request.headers['Authorization'], 'Bearer new-a');
        return http.Response(jsonEncode({'ok': true}), 200);
      }),
    );

    final results = await Future.wait([
      api.caibiBalance(),
      api.latestAppUpdate(),
    ]);

    expect(results, hasLength(2));
    expect(refreshCalls, 1);
    expect((await store.session())?.refreshToken, 'new-r');
  });

  test(
      'typed dual-domain API stores Business tokens then binds Matrix identity',
      () async {
    final storage = MemoryStore();
    final store = SecureSessionStore(storage);
    final api = BusinessApiClient(
      baseUri: Uri.parse('https://business.example'),
      sessionStore: store,
      client: MockClient((request) async {
        if (request.url.path == '/api/v1/auth/login') {
          expect(jsonDecode(request.body)['password'], 'business-password');
          return http.Response(
              jsonEncode({
                'access_token': 'business-a',
                'refresh_token': 'business-r'
              }),
              200);
        }
        expect(request.url.path, '/api/v1/auth/matrix-login-token');
        expect(request.headers['Authorization'], 'Bearer business-a');
        expect(request.body, isEmpty);
        return http.Response(
            jsonEncode({
              'login_token': 'matrix-once',
              'homeserver': 'https://matrix.example',
              'expires_in': 60,
              'matrix_user_id': '@alice:matrix.example',
            }),
            200);
      }),
    );

    await api.loginBusiness(
        username: 'alice',
        password: 'business-password',
        deviceKey: 'device-1',
        deviceName: '畅聊移动端');
    final grant = await api.issueMatrixLoginToken();
    await api.bindMatrixUserId('@alice:matrix.example');

    expect(grant, isA<MatrixLoginGrant>());
    expect(grant.loginToken, 'matrix-once');
    expect(grant.matrixUserId, '@alice:matrix.example');
    expect((await store.session())?.matrixUserId, '@alice:matrix.example');
  });

  test(
      'registration retry reuses the original idempotency key after a lost response',
      () async {
    final keys = <String>[];
    var calls = 0;
    final api = BusinessApiClient(
      baseUri: Uri.parse('https://business.example'),
      sessionStore: SecureSessionStore(MemoryStore()),
      client: MockClient((request) async {
        keys.add(request.headers['Idempotency-Key']!);
        calls++;
        if (calls == 1) throw http.ClientException('response lost');
        return http.Response(
          jsonEncode({
            'registration_session': 'session-1',
            'status': 'PENDING_EMAIL',
            'resend_after_seconds': 60,
          }),
          202,
        );
      }),
    );

    await expectLater(
      api.register(
        username: 'alice',
        email: 'alice@example.test',
        password: 'business-password',
        invitationCode: 'INVITE',
      ),
      throwsA(isA<http.ClientException>()),
    );
    await api.register(
      username: 'alice',
      email: 'alice@example.test',
      password: 'business-password',
      invitationCode: 'INVITE',
    );

    expect(keys, hasLength(2));
    expect(keys[1], keys[0]);
  });

  test('verification retries reuse a key only for an identical credential',
      () async {
    final keys = <String>[];
    final api = BusinessApiClient(
      baseUri: Uri.parse('https://business.example'),
      sessionStore: SecureSessionStore(MemoryStore()),
      client: MockClient((request) async {
        keys.add(request.headers['Idempotency-Key']!);
        return http.Response(
          jsonEncode({
            'error': {
              'code': 'EMAIL_VERIFICATION_CODE_INVALID',
              'message': 'invalid verification code',
            },
          }),
          422,
        );
      }),
    );

    await expectLater(
      api.verifyEmail(registrationSession: 'session-1', code: '000000'),
      throwsA(isA<BusinessApiException>()),
    );
    await expectLater(
      api.verifyEmail(registrationSession: 'session-1', code: '111111'),
      throwsA(isA<BusinessApiException>()),
    );

    expect(keys, hasLength(2));
    expect(keys[1], isNot(keys[0]));
  });
}
