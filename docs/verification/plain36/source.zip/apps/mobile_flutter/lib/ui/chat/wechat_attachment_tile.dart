import 'package:flutter/cupertino.dart';
import '../foundation/wechat_tokens.dart';

final class WeChatAttachmentTile extends StatelessWidget {
  const WeChatAttachmentTile(
      {super.key, required this.name, required this.progress, this.onRetry});
  final String name;
  final double progress;
  final VoidCallback? onRetry;
  @override
  Widget build(BuildContext context) => Container(
      padding: const EdgeInsets.all(WeChatSpacing.md),
      decoration: BoxDecoration(
          color: CupertinoTheme.of(context).barBackgroundColor,
          borderRadius: BorderRadius.circular(WeChatRadius.bubble)),
      child: Row(children: [
        const Icon(CupertinoIcons.doc),
        const SizedBox(width: WeChatSpacing.sm),
        Expanded(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(name),
          CupertinoActivityIndicator.partiallyRevealed(
              progress: progress.clamp(0, 1))
        ])),
        if (onRetry != null)
          CupertinoButton(onPressed: onRetry, child: const Text('重试'))
      ]));
}
