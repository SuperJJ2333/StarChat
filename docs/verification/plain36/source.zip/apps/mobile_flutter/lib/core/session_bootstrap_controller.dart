import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:matrix/matrix.dart';

import '../features/matrix/matrix_e2ee_client.dart';
import 'business_api_client.dart';
import 'cache/cache_repository.dart';

enum SessionBootstrapStatus {
  loading,
  authenticated,
  offlineAuthenticated,
  unauthenticated,
  fatalError,
}

final class SessionBootstrapState {
  const SessionBootstrapState(this.status, {this.message});
  final SessionBootstrapStatus status;
  final String? message;
}

final class SessionBootstrapController extends ChangeNotifier {
  SessionBootstrapController({required this.business, required this.matrix});

  final BusinessSessionGateway business;
  final MatrixSessionGateway matrix;
  SessionBootstrapState state =
      const SessionBootstrapState(SessionBootstrapStatus.loading);

  Future<void> bootstrap() async {
    _set(const SessionBootstrapState(SessionBootstrapStatus.loading));
    try {
      final businessResult = await business.restoreSession();
      if (businessResult == BusinessSessionRestore.absent ||
          businessResult == BusinessSessionRestore.invalid) {
        // 业务会话失效（登出/令牌过期/瞬时刷新失败）时【不得】清除本地
        // 加密数据库：同账号重新登录后必须仍能解密历史消息。账号隔离
        // 由登录流程的身份校验保证（不同账号登录时才重置本地库）。
        _set(const SessionBootstrapState(
            SessionBootstrapStatus.unauthenticated));
        return;
      }
      if (!matrix.isLoggedIn) {
        await _bestEffortBusinessLogout();
        _set(const SessionBootstrapState(
            SessionBootstrapStatus.unauthenticated));
        return;
      }
      final expectedMatrixUser = await business.currentMatrixUserId();
      if (expectedMatrixUser == null || expectedMatrixUser != matrix.userId) {
        _set(const SessionBootstrapState(
          SessionBootstrapStatus.fatalError,
          message: '本地登录身份不一致，请联系技术支持',
        ));
        return;
      }
      try {
        await matrix.sync();
      } on MatrixException catch (error) {
        if (error.errcode == 'M_UNKNOWN_TOKEN' ||
            error.errcode == 'M_FORBIDDEN') {
          await _bestEffortBusinessLogout();
          await _bestEffortMatrixReset();
          _set(const SessionBootstrapState(
            SessionBootstrapStatus.unauthenticated,
            message: '登录状态已失效，请重新登录',
          ));
          return;
        }
        rethrow;
      } on SocketException {
        _set(const SessionBootstrapState(
            SessionBootstrapStatus.offlineAuthenticated));
        return;
      } on TimeoutException {
        _set(const SessionBootstrapState(
            SessionBootstrapStatus.offlineAuthenticated));
        return;
      } on http.ClientException {
        _set(const SessionBootstrapState(
            SessionBootstrapStatus.offlineAuthenticated));
        return;
      }
      _set(SessionBootstrapState(
        businessResult == BusinessSessionRestore.offline
            ? SessionBootstrapStatus.offlineAuthenticated
            : SessionBootstrapStatus.authenticated,
      ));
    } on SocketException {
      _offlineIfPossible();
    } on TimeoutException {
      _offlineIfPossible();
    } on http.ClientException {
      _offlineIfPossible();
    } catch (_) {
      _set(const SessionBootstrapState(
        SessionBootstrapStatus.fatalError,
        message: '无法恢复本地登录状态',
      ));
    }
  }

  Future<void> logout() async {
    // U04：登出即清除**当前账号**的朋友圈快照（账号命名空间键）——
    // 下一个账号首绘绝不能看到上一个账号的 feed；不触碰 Matrix 聊天
    // 历史与其他账号数据。
    await _clearAccountMomentsCache();
    await _bestEffortBusinessLogout();
    await _bestEffortMatrixSuspend();
    _set(const SessionBootstrapState(SessionBootstrapStatus.unauthenticated));
  }

  Future<void> _clearAccountMomentsCache() async {
    try {
      // 与 MomentsPage 同一命名空间（matrix:<userId>）：登出清当前账号。
      final matrixUserId = await business.currentMatrixUserId();
      if (matrixUserId == null || matrixUserId.isEmpty) return;
      final repository = await CacheRepository.instance();
      await repository.momentsFor('matrix:$matrixUserId').clear();
    } catch (_) {
      // 缓存清理尽力而为，不阻断登出。
    }
  }

  void _offlineIfPossible() {
    _set(SessionBootstrapState(
      matrix.isLoggedIn
          ? SessionBootstrapStatus.offlineAuthenticated
          : SessionBootstrapStatus.unauthenticated,
    ));
  }

  Future<void> _bestEffortBusinessLogout() async {
    try {
      await business.logout();
    } catch (_) {}
  }

  Future<void> _bestEffortMatrixSuspend() async {
    try {
      await matrix.suspend();
    } catch (_) {}
  }

  Future<void> _bestEffortMatrixReset() async {
    try {
      await matrix.resetLocalStore();
    } catch (_) {}
  }

  void _set(SessionBootstrapState next) {
    state = next;
    notifyListeners();
  }
}
